Rails.application.routes.draw do

  root to: 'urlshorter#index'
  get 'urlshorter#urlgen'
  get "/:short_url", to: "urlshorter#show"
  # get "shortened/:short_url", to: "urls#shortened", as: :shortened
  resources :urls, only: :create
  

  # get 'urlshorter/index'
  # root 'urlshorter#index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
