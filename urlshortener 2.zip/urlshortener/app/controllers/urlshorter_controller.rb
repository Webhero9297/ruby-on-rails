require 'scrab'
class UrlshorterController < ApplicationController
  before_action :find_url, only: [:show, :urlgen]
  def index
    
  end
  def show
    redirect_to @url.sanitized_url    
  end

  def urlgen
    search_key = params[:Keywords]
    search_data_asin = params[:AmazonASIN]
    filter_key = String.new(search_key)
    filter_key = filter_key.gsub! ' ', '+'
    url = "https://www.amazon.com/s/ref=nb_sb_noss_1?url=search-alias%3Daps&field-keywords=#{filter_key}"

    scraper = Scraper.new(url, search_data_asin)

    prod_url = "amazon.com/Luxurious-Natural-Brushing-Brush-Bundle/dp/#{search_data_asin}"
    srch_rank_value = "/ref=sr_1_#{scraper.get_rank}_s_it"
    new_value_found = "/139-1154908-8297564?"
    section_value = "s=beauty"
    encoding = "ie=UTF8"
    unix_timecode = Time.now.to_i
    sr_rank_value = "1-#{scraper.get_rank}"
    origin_url = "https://www.#{prod_url}#{srch_rank_value}#{new_value_found}#{section_value}&#{encoding}&qid=#{unix_timecode}&sr=#{sr_rank_value}&keywords=#{filter_key}"
    
    url_param = { original_url:origin_url }
    short_url = ''
    @url = Url.new(url_param)
    @url.sanitize
    if @url.new_url?
        if @url.save
            short_url = @url.short_url
        else
            render 'index'
        end
    else
        short_url = @url.find_duplicate.short_url
    end

    @resp = { origin_keyword: search_key, rank: scraper.get_rank, prod_url: prod_url,srch_rank_value: srch_rank_value, new_value_found:new_value_found, section_value:section_value, encoding:encoding,
              unix_timecode: unix_timecode, sr_rank_value: sr_rank_value, filter_keyword:filter_key, origin_url: origin_url, short_url: short_url }
  end
  private

  def find_url
    search_key = params[:Keywords]
    search_data_asin = params[:AmazonASIN]
    filter_key = String.new(search_key)
    filter_key = filter_key.gsub! ' ', '+'
    url = "https://www.amazon.com/s/ref=nb_sb_noss_1?url=search-alias%3Daps&field-keywords=#{filter_key}"

    scraper = Scraper.new(url, search_data_asin)

    prod_url = "amazon.com/Luxurious-Natural-Brushing-Brush-Bundle/dp/#{search_data_asin}"
    srch_rank_value = "/ref=sr_1_#{scraper.get_rank}_s_it"
    new_value_found = "/139-1154908-8297564?"
    section_value = "s=beauty"
    encoding = "ie=UTF8"
    unix_timecode = Time.now.to_i
    sr_rank_value = "1-#{scraper.get_rank}"
    origin_url = "https://www.#{prod_url}#{srch_rank_value}#{new_value_found}#{section_value}&#{encoding}&qid=#{unix_timecode}&sr=#{sr_rank_value}&keywords=#{filter_key}"
    @url = Url.find_by_sanitized_url(origin_url)
  end
end
