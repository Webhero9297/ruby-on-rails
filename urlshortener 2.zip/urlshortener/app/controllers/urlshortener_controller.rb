class UrlshortenerController < ApplicationController
  def show
  end
end
