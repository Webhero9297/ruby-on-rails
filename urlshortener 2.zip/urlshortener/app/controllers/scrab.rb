require 'nokogiri'
require 'open-uri'
require 'httparty'
require 'Pry'
require 'net/http'
APPLICATION_NAME = "Httparty"
class Scraper
  include HTTParty
  attr_accessor :parse_page
  attr_accessor :url, :search_data_asin, :rank_value

  def initialize(url, search_data_asin)          
    self.url = url
    self.search_data_asin = search_data_asin
    
    page = HTTParty.post(self.url, headers: {"User-Agent" => APPLICATION_NAME})
    parse_page = Nokogiri::HTML(page)
    nodes = parse_page.search("//li[@class='s-result-item s-result-card-for-container s-carded-grid celwidget ']")
    a=[]
    nodes.each do |node|
      id = node.attribute 'id'
      data_asin = node.attribute 'data-asin'
      if data_asin.value == search_data_asin
        self.rank_value = id.value.split("_").last
      end
    end
  end
  def get_rank
    return self.rank_value
  end
end

#Pry.start(binding)
