require 'test_helper'

class UrlshortenerControllerTest < ActionDispatch::IntegrationTest
  test "should get show" do
    get urlshortener_show_url
    assert_response :success
  end

end
