require 'test_helper'

class CsvdatatableTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
