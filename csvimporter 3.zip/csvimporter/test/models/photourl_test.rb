require 'test_helper'

class PhotourlTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
