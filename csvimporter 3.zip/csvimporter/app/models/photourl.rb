class Photourl < ApplicationRecord
end
