module MainpageHelper
end
